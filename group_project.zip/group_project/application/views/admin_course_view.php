<!-- Page preloader -->
<div id="preloader">
  <div class="loader"> </div>
</div>

<section class="hero-section set-bg" data-setbg="public/img/bg.svg">
<div class="container h-100">
  <div class="hero-content text-white">
    <div class="row">
      <div class="title">
        <h2>Course Details</h2>
      </div>
    </div>
  </div>
</div>
</section>

<section class="table-section">
  <div class="container">
    <table>
      <tr>
        <th> Course ID </th>
        <th> Course Name </th>
        <th> Course Description </th>
        <th> Syllabus </th>
        <th> Credits </th>
        <th> Fee </th>
      </tr>

      <?php  
         foreach ($course_data as $row)  
         {  
            ?><tr>  
            <td><?php echo $row->courseId;?></td>  
            <td><?php echo $row->courseName;?></td>  
            <td><?php echo $row->courseDesc;?></td>  
            <td><?php echo $row->syllabus;?></td>  
            <td><?php echo $row->credits;?></td>  
            <td><?php echo $row->courseFee;?></td>  
            </tr>  
         <?php }  
         ?>  

    </table>
  </div>
</section>

<style>
.hero-section 
{
  height:400px;
  overflow:hidden;
}

.hero-content h2 
{
  font-size: 5.625rem;
  font-weight:600;
  text-align: center;
  margin-top: 120px;
  line-height:1;
}

table {
  margin-top: 30px;
  margin-bottom: 30px;
  border:1px solid black;
  width: 100%;
}

th, td {
  border:1px solid black;
}

</style>