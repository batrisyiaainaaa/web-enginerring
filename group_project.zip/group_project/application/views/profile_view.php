<section class="spad set-bg" data-setbg="public/img/bg.svg">
<form id="updateProfile" action="<?=base_url()?>profile/updateProfile" method="post" style="border:1px solid #ccc">

	<div class="container" >
	 <h1> Edit Profile </h1>
	 <!-- <p><?php echo $this->session->flashdata('status'); ?></p>
	 <?php $string = validation_errors(); if(!empty($string)): ?>
	 <?php echo'<div class="alert" style="width:60%">' .validation_errors(). '</div>' ?>
	 <?php endif; ?> -->
	 <hr>

	 <label for="name"><b>Student ID</b></label>
	 <input type="text" placeholder="Enter Student ID" name="stdId" value="" required>

	 <label for="name"><b>Full Name</b></label>
	 <input type="text" placeholder="Enter Full Name" name="stdName" value="" required>

	 <label for="country"><b>Gender</b></label>
	    <select name="cCountry" id="scountry">
	      <option value="" disabled="disabled" selected="stdGender">Please Select</option> 
	         <option value="1" > Male</option>
	         <option value="2" > Female</option>
	    </select>

	 <label for="name"><b>Program</b></label>
	 <input type="text" placeholder="Enter Program Name" name="stdProgram" value="Vtuber" required>

	 <label for="name"><b>Current Year</b></label>
	 <input type="text" placeholder="Enter Current Year" name="stdYear" value="2021/2022-2" required>

	 <label for="name"><b>Phone Number</b></label>
	 <input type="text" placeholder="Enter Phone Number" name="stdPhone" value="0138921975" required>

	 <label for="name"><b>Email</b></label>
	 <input type="text" placeholder="Enter Email" name="stdEmail" value="a@gmail.com" required>

	 <label for="name"><b>Password</b></label>
	 <input type="text" placeholder="Enter Password" name="stdPassword" value="a12345" required> 

	 <label for="name"><b>Address Line 1</b></label>
	 <input type="text" placeholder="Enter Address Line 1 " name="stdAdd1" value="a" required>

	 <label for="name"><b>Address Line 2</b></label>
	 <input type="text" placeholder="Enter Address Line 2 " name="stdAdd2" value="a" required>

	 <label for="name"><b>City</b></label>
	 <input type="text" placeholder="Enter City Name" name="stdCity" value="Tawau" required>

	 <label for="state"><b>State</b></label>
	 <input type="text" placeholder="Enter State " name="stdState" value="Sabah" required>

	 <label for="postal"><b>Postal Code</b></label>
	 <input type="text" placeholder="Enter Postal Code" name="stdPostal" value="91000" required>

	 <label for="country"><b>Country</b></label>
	 <input type="text" placeholder="Enter Country" name="stdCountry" value="Malaysia" required>

	 <div class="clearfix">
	 	<button type="button" class="cancelbtn">Cancel</button>
	 	<button type="submit" class="updatebtn">Update</button>
	 </div>
</div>
</section>
</form>


<style> 

body {font-family: Arial, Helvetica, sons-serif;}
* {box-sizing: border-box}
                                                                 
/* Full-width input fields */                                                           
input[type=text], input[type=password],input[type=email], select {
 width: 100%;
 padding: 15px;
 margin: 5px 0 22px 0; 
 display: inline-block; 
 border: none;
 background: #f1f1f1;
}
                                                                                        
input[type=text]:focus, input[type=password]:focus, input[type=email]:focus, select:focus { 
 background-color: #ddd;
 outline: none;
}
                                                                                        
hr {
 border: 1px solid #f1f1f1; 
 margin-bottom: 25px;
}

button {
	background-color: #4CAF50;
	color: white;
	padding: 14px 20px;
	margin: 8px 0;
	border: none;
	cursor: pointer;
	width: 20%;
	opacity: 0.9;
}

button:hover {
	opacity: 1;
}

.container h1 {
	color: white;
	font-size: 4.375rem;
}
.container b {
	color: white;
}

/* Extra styles for the cancel button */
.cancelbtn {
	padding: 14px 20px;
background-color: #f44336;
}

/* Float cancel and signup buttons and add an equal width */
.cancelbtn, .updatebtn {
	float:  left;
	margin-right: 15px;
	width: 20%;
	border-radius: 15px;
}

/* Add padding to container elements */
.container {
	padding: 16px;
	width: 80%;
}

/*clear float */
.clearfix::after {
	content: "";
	clear: both;
	display: table;
}

.alert {
	padding: 20px;
	background-color: #f44336;
	color: white;
}

.alert_green {
	padding: 20px;
	background-color: #00cc66;
	color: white;
}

@media screen and (max-width: 20300px) {
	.cancelbtn, .signupbtn {
		width: 20%;
	}
}
</style>